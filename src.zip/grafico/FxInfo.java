package grafico;

import java.sql.SQLException;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import dao.ConexaoDAO;

/**
 * Cena inicial, onde será informado os dados para a conexao.
 * @author nataniel
 */
public class FxInfo {

    private Scene info = null;
    private GridPane pn = null;
    private String ipC = "";
    private String user = "";
    private String pass = "";

    public String getIpC() {
        return ipC;
    }

    public FxInfo(Stage ps, ConexaoDAO con) {
        pn = new GridPane();
        info = new Scene(pn, 250, 360);
        
        TextField ip = new TextField();
        TextField porta = new TextField();
        TextField usu = new TextField();
        PasswordField senh = new PasswordField();
        Button bt = new Button("Conectar");

        pn.add(new HBox(32.0, new Label("Ip:"), ip), 0, 0);
        pn.add(new HBox(14.0, new Label("Porta:"), porta), 0, 1);
        pn.add(new HBox(3.0, new Label("Usuario:"), usu), 0, 2);
        pn.add(new HBox(11.0, new Label("Senha:"), senh), 0, 3);
        pn.add(new HBox(19,bt), 0, 4);
        bt.setOnAction(e -> {
            ipC = ip.getText();
            Alert ale = new Alert(Alert.AlertType.INFORMATION);
            ale.setHeaderText("Estamos tentando conecatar.");
            ale.setTitle("Conectando...");
            ale.setContentText("Aguarde um pouco... isso pode demorar um pouco.");
            ale.show();
            try {
                Integer.parseInt(porta.getText());

                if (!ipC.contains("jdbc:mysql://")) {
                    StringBuilder c = new StringBuilder();
                    c.append("jdbc:mysql://");
                    c.append(ip.getText());
                    c.append(":");
                    c.append(porta.getText());
                    ipC = c.toString();
                }
                con.fazerConexaoT(new String[]{ipC, usu.getText(), senh.getText()});
                this.user = usu.getText();
                this.pass = senh.getText();
                ps.setScene(new FxInfo2(con, this, ps).getCena());
                ale.close();
            } catch (NumberFormatException err) {
                ale.setHeaderText("Ops... Achei um erro!");
                ale.setContentText("Você colocou algo que não seja numero na porta!");
            } catch (SQLException er2) {
                ale.setAlertType(Alert.AlertType.ERROR);
                ale.setHeaderText("Isso não é nosso... Eu juro!");
                ale.setContentText("Não foi possivel conectar no Banco de Dados!");
                er2.printStackTrace();
            }
        });
    }

    public String getUser() {
        return user;
    }

    public String getPass() {
        return pass;
    }

    public Scene getInfo() {
        return info;
    }
}
