package grafico;

import grafico.dialogos.FxDiag;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import dao.AutoComandoDAO;
import dao.InfoCenterDAO;
import java.util.ArrayList;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.stage.Stage;

/**
 *
 * @author nataniel
 */
public class FxTabela {

    private TableView<ObservableList<String>> vt = null;
    private Scene cena = null;
    private Button bt = null;
    private Button bt2 = null;
    private Button bt3 = null;
    private Button bt4 = null;
    private FlowPane tab = null;
    private InfoCenterDAO ct = null;
    private FxDiag diag = null;
    private String tabelaNome = "";
    private AutoComandoDAO com = null;
    private List<TableColumn<ObservableList<String>, String>> tbc=null;
    /**
     * Construdor que "constroi" a cena e coloca em devido canto cada controle.
     * O constudor tambem contem as ações da TableView e dos Botões.
     *
     * @param ct Nescessario informar a classe InfoCenter, na qual irá ser util
     * pra prati- camente tudo.
     * @param status usado para descobrir o status.
     * @param info2 usado para voltar a seleção de bancos de dados
     * @param st usado voltar a seleção de banco de dados
     * @param com AutoComano será nescessario pra, praticamente, tudo tambem,
     * porém sua caracteristica maior será pra atualizar (Olhe o codigo da
     * classe).
     * @see AutoComandoDAO
     * @param tabela Será nescessario, principalmente, para os comandos de
     * atualização e outros como update, insert e delete.
     */
    public FxTabela(InfoCenterDAO ct, AutoComandoDAO com, Stage st, String tabela, Scene info2, boolean status) {
        vt = new TableView();
        diag = new FxDiag();
        tabelaNome = tabela;
        this.com = com;
        this.ct = ct;
        bt2 = new Button("Inserir");
        bt3 = new Button("Remover");
        bt4 = new Button("Voltar");
        bt3.setVisible(false);
        tbc = ct.getColunas();
        ArrayList<List<String>> cont = ct.getConteudo();

        for (int i = 0; i != tbc.size(); i++) {
            int ss = i;
            TableColumn<ObservableList<String>, String> Col = tbc.get(i);
            Col.setCellValueFactory((param) -> {
                StringProperty spt;
                if (ss >= param.getValue().size()) {
                    spt = new SimpleStringProperty("");
                } else {
                    spt = new SimpleStringProperty(param.getValue().get(ss));
                }
                return spt;
            });
            vt.getColumns().add(Col);
        }
        if (!ct.isTabelaLimpa()) {
            for (int i = 0; i != cont.size(); i++) {
                List<String> ls = cont.get(i);
                vt.getItems().add(FXCollections.observableArrayList(ls));
            }
        }
        this.acoes(vt);
        bt = new Button("Atualizar dados");

        bt3.setOnAction(e
                -> {
            List dados = vt.getSelectionModel().getSelectedItem();
            StringBuilder bd = new StringBuilder();
            bd.append("delete from ");
            bd.append(tabela);
            bd.append(" where ");
            for (int i = 0; i != this.ct.getColunaQuant(); i++) {
                bd.append("`");
                bd.append(ct.getColunaNome()[i]);
                bd.append("`");
                bd.append("=");
                if (tbc.get(i).getUserData().equals("VARCHAR")) {
                    bd.append("'");
                    bd.append(dados.get(i));
                    bd.append("'");
                } else if (tbc.get(i).getUserData().equals("INT")) {
                    bd.append(dados.get(i));
                } else if (tbc.get(i).getUserData().equals("DATE")) {
                    bd.append("'");
                    bd.append(dados.get(i));
                    bd.append("'");
                } else {
                    bd.append("'");
                    bd.append(dados.get(i));
                    bd.append("'");
                }
                if (i + 1 != ct.getColunaQuant()) {
                    bd.append(" and ");
                }
            }
            com.novocomando(bd.toString());
            com.novocomando("select * from " + tabela);
            this.ct.atualizar(com.obterResultado());
            if (!ct.isTabelaLimpa()) {
                this.atualizar();
            } else {
                vt.getItems().clear();
            }
            bt3.setVisible(false);
        }
        );
        if (!status) {
            bt.setOnAction(e -> {
                bt.setVisible(false);
                this.com.novocomando("select * from " + tabela);
                this.ct.atualizar(this.com.obterResultado());
                if (!ct.isTabelaLimpa()) {
                    this.atualizar();
                }
                bt.setVisible(true);
            });
        } else {
            bt.setOnAction(e -> {
                bt.setVisible(false);
                this.ct.atualizar(com.novocomando("show status"));
                if (!ct.isTabelaLimpa()) {
                    System.out.println("if");
                    this.atualizar();
                } else {
                    vt.getColumns().clear();
                    vt.getItems().clear();
                }
                bt.setVisible(true);
            });
        }

        bt2.setOnAction(e
                -> {
            diag.reniciar();
            StringBuilder bd = new StringBuilder();
            List<String> conteudoL = new ArrayList();
            while (!diag.isFeito() && diag.getResultado() == 0) {
                conteudoL.add(diag.mostrarInserir(ct.getColunaNome()));
            }
            if (diag.getResultado() == 4) {
                bd.append("insert into ").append(tabelaNome).append(" (");
                for (int dd = 0; dd != this.ct.getColunaQuant(); dd++) {
                    bd.append("`");
                    bd.append(ct.getColunaNome()[dd]);
                    bd.append("`");
                    if (dd + 1 != ct.getColunaQuant()) {
                        bd.append(",");
                    }
                }
                bd.append(") values (");
                for (int dd = 0; dd != this.ct.getColunaQuant(); dd++) {
                    if (tbc.get(dd).getUserData().equals("VARCHAR")) {
                        bd.append("'");
                        bd.append(conteudoL.get(dd));
                        bd.append("'");
                    } else if (tbc.get(dd).getUserData().equals("INT")) {
                        bd.append(conteudoL.get(dd));
                    } else if (tbc.get(dd).getUserData().equals("DATE")) {
                        bd.append("'");
                        bd.append(conteudoL.get(dd));
                        bd.append("'");
                    } else {
                        bd.append("'");
                        bd.append(conteudoL.get(dd));
                        bd.append("'");
                    }
                    if (dd + 1 != ct.getColunaQuant()) {
                        bd.append(",");
                    }
                }
                bd.append(")");
                com.novocomando(bd.toString());
                com.novocomando("select * from " + tabelaNome);
                this.ct.getLinhaConteudo().clear();
                this.ct.atualizar(com.obterResultado());
                if (!ct.isTabelaLimpa()) {
                    this.atualizar();
                }
            }
        }
        );
        bt4.setOnAction(e
                -> {
            st.setScene(info2);
        }
        );
        VBox pn = new VBox();
        FlowPane pn2 = new FlowPane(5, 5);
        tab = new FlowPane(10, 10);
        cena = new Scene(pn, 400, 460);

        vt.setMaxHeight(cena.getHeight());
        vt.setMaxWidth(cena.getWidth());

        tab.getChildren()
                .add(vt);
        pn.getChildren()
                .addAll(tab, pn2);
        if (!status) {
            pn2.getChildren().addAll(bt, bt4, bt2, bt3);
        } else {
            pn2.getChildren().addAll(bt, bt4);
        }
    }

    /**
     * Ela evita que se escreva a mesma coisa.
     */
    /**
     * Metodo que Atualiza a tabela e serve tambem pra criar a mesma
     */
    public void atualizar() {
        ct.limparColuna();
        vt.getColumns().clear();
        vt.getItems().clear();
        tbc = ct.getColunas();
        ArrayList<List<String>> cont = ct.getConteudo();
        for (int i = 0; i != tbc.size(); i++) {
            int ss = i;
            TableColumn<ObservableList<String>, String> Col = tbc.get(i);
            Col.setCellValueFactory((param) -> {
                StringProperty spt;
                if (ss >= param.getValue().size()) {
                    spt = new SimpleStringProperty("");
                } else {
                    spt = new SimpleStringProperty(param.getValue().get(ss));
                }
                return spt;
            });
            vt.getColumns().add(Col);
        }
        if (!ct.isTabelaLimpa()) {
            for (int i = 0; i != cont.size(); i++) {
                List<String> ls = cont.get(i);
                vt.getItems().add(FXCollections.observableArrayList(ls));
            }
        }
    }

    public Scene getCena() {
        return cena;
    }

    public final void acoes(TableView<ObservableList<String>> vt) {
        vt.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2 && vt.getSelectionModel().getSelectedItem() != null) {
                System.out.println("if");
                List<String> antigo = vt.getSelectionModel().getSelectedItem();
                String[] valores = new String[ct.getColunaQuant()];

                for (int i = 0; i != valores.length; i++) {
                    valores[i] = antigo.get(i);
                }

                diag.reniciar();
                StringBuilder bd = new StringBuilder();
                List<String> conteudoL = new ArrayList();
                while (!diag.isFeito() && diag.getResultado() == 0) {
                    conteudoL.add(diag.mostrarAtualizar(ct.getColunaNome(), valores));
                }
                if (diag.getResultado() == 4) {
                    bd.append("update ").append(tabelaNome).append(" set ");
                    for (int dd = 0; dd != this.ct.getColunaQuant(); dd++) {
                        bd.append("`");
                        bd.append(ct.getColunaNome()[dd]);
                        bd.append("`");
                        bd.append("=");
                    if (tbc.get(dd).getUserData().equals("VARCHAR")) {
                        bd.append("'");
                        bd.append(conteudoL.get(dd));
                        bd.append("'");
                    } else if (tbc.get(dd).getUserData().equals("INT")) {
                        bd.append(conteudoL.get(dd));
                    } else if (tbc.get(dd).getUserData().equals("DATE")) {
                        bd.append("'");
                        bd.append(conteudoL.get(dd));
                        bd.append("'");
                    } else {
                        bd.append("'");
                        bd.append(conteudoL.get(dd));
                        bd.append("'");
                    }    if (dd + 1 != ct.getColunaQuant()) {
                            bd.append(",");
                        }
                    }
                    bd.append(" where ");
                    for (int i = 0; i != this.ct.getColunaQuant(); i++) {
                        bd.append("`");
                        bd.append(ct.getColunaNome()[i]);
                        bd.append("`");
                        bd.append("=");
                        if (tbc.get(i).getUserData().equals("VARCHAR")) {
                        bd.append("'");
                        bd.append(valores[i]);
                        bd.append("'");
                    } else if (tbc.get(i).getUserData().equals("INT")) {
                        bd.append(valores[i]);
                    } else if (tbc.get(i).getUserData().equals("DATE")) {
                        bd.append("'");
                        bd.append(valores[i]);
                        bd.append("'");
                    } else {
                        bd.append("'");
                        bd.append(valores[i]);
                        bd.append("'");
                    }if (i + 1 != ct.getColunaQuant()) {
                            bd.append(" and ");
                        }
                    }
                    com.novocomando(bd.toString());
                    com.novocomando("select * from " + tabelaNome);
                    this.ct.getLinhaConteudo().clear();
                    this.ct.atualizar(com.obterResultado());
                    if (!ct.isTabelaLimpa()) {
                        this.atualizar();
                    }
                }
            } else if (e.getClickCount() == 1) {
                if (bt3.isVisible()) {
                    vt.getSelectionModel().clearSelection();
                    bt3.setVisible(false);
                } else {
                    bt3.setVisible(true);
                }
            }
        });
    }
}
