/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import grafico.FxInfo;
import javafx.application.Application;
import javafx.stage.Stage;
import dao.ConexaoDAO;

/**
 *
 * @author nataniel
 */
public class Main extends Application{
    public static void main(String[] args) {
        launch(args);
    }
    private ConexaoDAO con=null;

    @Override
    public void start(Stage ps){
        
        con=new ConexaoDAO();
        FxInfo info=new FxInfo(ps,con);
        ps.setScene(info.getInfo());
        ps.setTitle("Gerenciador MySQL");
        
        ps.show();
    }
    
}
