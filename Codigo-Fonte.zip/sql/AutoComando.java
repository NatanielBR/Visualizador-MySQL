package sql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *  Classe que faz diversos procedimentos automaticos pra 
 * encurtar as linhas de codigo.
 * @author nataniel
 */
public class AutoComando {
    private Connection conexao=null;
    private String ulComando="";
    private Statement st=null;
    private ResultSet rs=null;
    /**
     * Metodo que irá retornar o resultado do comando.
     * @return 
     * Uma ResultSet contendo o resultado do comando.
     * Será null se o comando for insert,update ou delete.
     */
    public ResultSet obterResultado(){
        return rs;
    }
    /**
     * Metodo que irá executar o comando e ira retornar o resultado.
     * @param comando
     * Comando em String.
     * @return 
     * Resultado em ResultSet.
     * Será null se o comando for insert,update ou delete.
     */
    public ResultSet novocomando(String comando){
        try {
            
            ulComando=comando;
            st=null;
            st=conexao.createStatement();
            if(comando.contains("insert")||comando.contains("update")||comando.contains("delete")){
                st.execute(comando);
                st=null;
            }else if(comando.contains("select")){
                rs=st.executeQuery(comando);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao realizar o comando.");
            System.err.println("\tcomando: \""+comando+"\" .");
            System.err.println("\t\tClasse: 'AutoComando' .");
            System.err.println("\t\t\tMetodo: 'novoComando' .");
            e.printStackTrace();
        }
        return rs;
    }
    /**
     * Metodo que executa o utlimo comando.
     * É nescessario usar o metodo obterResultado pra realmente obter o resultado.
     */
    public void autoComando(){
        this.novocomando(ulComando);
    }
    /**
     * Construdor que irá nescessita uma conexao e um comando inicial.
     * @param con
     * Uma Connection pra executar os comandos.
     * @param comando 
     * O comando em si.
     */
    public AutoComando(Connection con, String comando) {
        conexao=con;
        ulComando=comando;
        try {
            st=conexao.createStatement();
            if(comando.contains("insert")||comando.contains("update")){
                st.execute(comando);
                st=null;
            }else{
                rs=st.executeQuery(comando);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao realizar o procedimento automatico.");
            System.err.println("\tClasse: AutoComando");
            e.printStackTrace();
            System.exit(1);
        }
    }
    
}
