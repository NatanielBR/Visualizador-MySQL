package sql;

/**
 * Uma das principais classes que serve pra amarzenar os dados das colunas e
 * forma um array e separa os dados em strings. Suporte maximo pra cinco colu-
 * nas.
 * Obs: ao observar o codigo de toda a aplicação se nota que o limite de colunas
 * pode ser facilmente alterado, um control-c aqui e um control-v ali, fiz dessa
 * maneira por duvida da quantidade maxima de colunas, caso descubra que 
 * possa existir uma uma tabela com mais de cinco colunas, eu posso facilmente
 * alterar certas partes do codigo para colocar o novo limite.
 * @author nataniel
 */
public class DadosColuna {

    public DadosColuna(int quant) {
        valores=new String[quant];
    }
    public DadosColuna() {
        valores=new String[5];
    }
    public void colunaConteuo(){
        
    }
    private String[] valores=null;
    private String[] colunas=null;

    public String[] getColunas() {
        return colunas;
    }
    
    public String[] getValores() {
        return valores;
    }
    public DadosColuna(String a,String b,String c,String d,String e) {
        valores=new String[5];
        colunas=new String[5];
        v1=a;
        v2=b;
        v3=c;
        v4=d;
        v5=e;
    }
    public DadosColuna(String a,String b,String c,String d) {
        valores=new String[4];
        colunas=new String[4];
        v1=a;
        v2=b;
        v3=c;
        v4=d;
    }
    public DadosColuna(String a,String b,String c) {
        valores=new String[3];
        colunas=new String[3];
        v1=a;
        v2=b;
        v3=c;
    }
    public DadosColuna(String a,String b) {
        valores=new String[2];
        colunas=new String[2];
        v1=a;
        v2=b;
    }
    public DadosColuna(String a){
        valores=new String[1];
        colunas=new String[1];
        v1=a;
    }
    private String v1 = "";
    private String v2 = "";
    private String v3 = "";
    private String v4 = "";
    private String v5 = "";

    public void setV1(String vl) {
        v1 = vl;
        valores[0]=v1;
    }

    public String getV1() {
        return v1;
    }

    public void setV2(String vl) {
        v2 = vl;
        valores[1]=vl;
    }

    public String getV2() {
        return v2;
    }

    public void setV3(String vl) {
        v3 = vl;
        valores[2]=vl;
    }

    public String getV3() {
        return v3;
    }

    public void setV4(String vl) {
        v4 = vl;
        valores[3]=vl;
    }

    public String getV4() {
        return v4;
    }

    public void setV5(String vl) {
        v5 = vl;
        valores[4]=vl;
    }

    public String getV5() {
        return v5;
    }

}
