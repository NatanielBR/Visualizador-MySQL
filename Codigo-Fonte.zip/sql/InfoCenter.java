/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javafx.scene.control.TableColumn;

/**
 *
 * @author nataniel
 */
public class InfoCenter {

    private boolean tabelaLimpa = false;
    private String[] colunaNome = null;

    public String[] getColunaNome() {
        return colunaNome;
    }

    public ArrayList getLinhaConteudo() {
        return linhaConteudo;
    }

    public int getColunaQuant() {
        return colunaQuant;
    }
    private ArrayList linhaConteudo = null;
    private int colunaQuant = 0;
    private int linhaQuant = 0;
    /**
     * Construtor que recebe uma resultset e agrupa os dados para os seguintes grupos:
     * #Nome da coluna: ele obtem os nomes das colunas e forma um array.
     * #Quantidade de Coluna: ele obtem a quantidade de colunas.
     * #Conteudo das colunas: atraves de uma logica, talvez simples, obtem o conteudo
     * das colunas e forma uma Lista (usando List).
     * #Quantidade de linha: Aqui irá estar a quantidade de linhas que a tabela
     * possui.
     * @param rs 
     */
    public InfoCenter(ResultSet rs) {
        try {
            if (rs.next()) {
                tabelaLimpa = false;
                rs.beforeFirst();
                try {
                    colunaQuant = rs.getMetaData().getColumnCount();
                    linhaConteudo = new ArrayList();
                    colunaNome = new String[colunaQuant];
                    for (int a = 0; a != this.colunaQuant; a++) {
                        colunaNome[a] = (rs.getMetaData().getColumnName(a + 1));
                    }
                    rs.beforeFirst();

                    while (!rs.isLast()) {
                        if (rs.next()) {
                            for (int b = 1; b != colunaQuant + 1; b++) {
                                linhaConteudo.add(rs.getObject(b));
                            }
                        }
                        linhaQuant++;
                    }
                } catch (SQLException err) {
                    System.err.println("Erro ao agrupar as informaçoes.\n   classe: 'InfoCenter' .\n Mensagem:");
                    err.printStackTrace();
                    System.exit(1);
                }
            } else {
                tabelaLimpa = true;
            }
        } catch (SQLException ex) {
        }
    }
    /**
    * Obter a quantidae de linhas.
    * @return 
    * Irá ser retornado a quantidade no tipo int.
    */
    public int getLinhaQuant() {
        return linhaQuant;
    }
    private void valorInclu(ResultSet rs) {
        try {
            if (rs.next()) {
                tabelaLimpa = false;
                rs.beforeFirst();
                linhaQuant = 1;
                
                try {
                    colunaQuant = rs.getMetaData().getColumnCount();
                    try {
                        linhaConteudo.clear();
                        for (int a = 0; a != this.colunaQuant; a++) {
                            colunaNome[a] = (rs.getMetaData().getColumnName(a + 1));
                        }
                    } catch (NullPointerException er) {
                        linhaConteudo = new ArrayList();
                        colunaQuant = rs.getMetaData().getColumnCount();
                        colunaNome = new String[colunaQuant];
                    }
                    for (int a = 0; a != this.colunaQuant; a++) {
                        colunaNome[a] = (rs.getMetaData().getColumnName(a + 1));
                    }
                    rs.beforeFirst();
                    while (!rs.isLast()) {
                        if (rs.next()) {
                            for (int b = 1; b != colunaQuant + 1; b++) {
                                linhaConteudo.add(rs.getObject(b));
                            }
                            linhaQuant++;
                        }
                    }
                } catch (SQLException err) {
                    System.err.println("Erro ao atualizar as informaçoes.\n   classe: 'InfoCenter' .\n Mensagem:");
                    err.printStackTrace();
                    System.exit(1);
                }
            } else {
                tabelaLimpa = true;
            }
        } catch (SQLException ex) {
        }
    }
    /**
     * Metodo pra saber se a tabela está limpa ou não, ou seja, sem conteudo.
     * @return 
     * Um valor boolean sendo:
     * true - esta limpa.
     * false - tem conteudo.
     */
    public boolean isTabelaLimpa() {
        return tabelaLimpa;
    }
    /**
     * Metodo pra receber os dados da Coluna, porem, aqui só será informado a quantidade de dados
     * que a coluna suporta.
     * @return 
     * Uma classe DadosColuna.
     * @see DadosColuna
     */
    public DadosColuna getDadosColuna() {
        return new DadosColuna(this.colunaQuant);
    }
    TableColumn<DadosColuna,Object>[] colunaA = null;
    /**
     * Metodo que irá formar um array com diversas colunas, ou somente uma,
     * com o nome de cada coluna.
     * @return 
     * Um array contendo todas as colunas que a tabela possui. 
     */
    public TableColumn<DadosColuna,Object>[] getTabela() {
        if (colunaA == null) {
            colunaA = new TableColumn[this.colunaQuant];
            for (int i = 0; i < colunaA.length; i++) {
                colunaA[i] = new TableColumn(colunaNome[i].toString());
            }
        }
        return colunaA;
    }
    /**
     * Metodo usado pra limpar o array contendo as colunas.
     */
    public void limparColuna(){
        colunaA=null;
    }
    /**
     * Metodo que executa o privato valorInclu(ResultSet) que irá refazer todo o
     * procedimento que o construtor fez, agrupar as informações porem, antes, 
     * irá verificar se a tabela esta limpa ou não.
     * @param rs 
     * È nescessario ter uma ResultSet tendo como comando usado
     * ("select * from"+nome da tabela).
     */
    public void atualizar(ResultSet rs) {
        this.valorInclu(rs);
    }

}
