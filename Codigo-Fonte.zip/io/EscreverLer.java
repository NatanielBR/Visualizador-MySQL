/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io;

import java.io.File;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author oregan-nt
 */
public class EscreverLer {

    private static PrintStream dos = null;
    private static Scanner is = null;

    public static void ativarEscrita(String nome) {
        try {
            dos = new PrintStream(nome);
        } catch (FileNotFoundException ex) {
            System.err.println("Erro ao ativar a escrita.");
        }
    }

    public static void fecharEscrita() {
        if (dos != null) {
            dos.close();
        }
    }

    public static void escrever(String conteudo) {
        dos.print(conteudo);
    }

    public static List ler(String nome) {
        List a = new ArrayList();
        File arq = new File(nome);
        try {
            is = new Scanner(arq);
            while (is.hasNextLine()) {
                a.add(is.nextLine());
            }
            is.close();
        } catch (FileNotFoundException ex) {
            a=null;
        }
        return a;
    }
}
