/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author oregan-nt
 */
public class EscreverLer {

    private static PrintStream dos = null;
    private static Scanner is = null;

    public static void ativarEscrita(String nome) {
        try {
            dos = new PrintStream(nome);
        } catch (FileNotFoundException ex) {
            System.err.println("Erro ao ativar a escrita.");
        }
    }

    public static void ativarEscrita(File nome) {
        try {
            dos = new PrintStream(nome);
        } catch (FileNotFoundException ex) {
            System.err.println("Erro ao ativar a escrita.");
        }
    }

    public static void fecharEscrita() {
        if (dos != null) {
            dos.close();
        }
    }

    public static void escrever(String conteudo) {
        if (!conteudo.equals("pl")) {
            dos.print(conteudo);
        }else{
            dos.println("");
        }
    }

    public static List ler(String nome) {
        List a = new ArrayList();
        File arq = new File(nome);
        try {
            is = new Scanner(arq);
            while (is.hasNextLine()) {
                a.add(is.nextLine());
            }
            is.close();
        } catch (FileNotFoundException ex) {
            a = null;
        }
        return a;
    }

    public static List ler(File nome) {
        List a = new ArrayList();
        try {
            is = new Scanner(nome);
            while (is.hasNextLine()) {
                a.add(is.nextLine());
            }
            is.close();
        } catch (FileNotFoundException ex) {
            a = null;
        }
        return a;
    }
}
