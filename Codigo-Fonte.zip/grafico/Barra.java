/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafico;

import dao.ConexaoDAO;
import java.util.List;
import javafx.scene.control.Alert;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

/**
 *
 * @author nataniel
 */
public class Barra {

    private MenuBar bar;
    private Menu m1, m2, m3;
    private MenuItem mi10,mi11, mi20, mi21, mi30;
    private List<String> saida = null;
    private List<String> entrada = null;

    public List<String> getSaida() {
        return saida;
    }

    public Barra(Stage ps) {
        bar = new MenuBar();
        m1 = new Menu("Servidor");
        m2 = new Menu("Tabela");
        m3 = new Menu("Sobre");
        mi10 = new MenuItem("Reconectar");
        mi10.setOnAction(e -> {
            ps.setScene(new FxInfo(ps, new ConexaoDAO()).getInfo());
        });
        mi11=new MenuItem("Nova tabela");
        mi20 = new MenuItem("Importar");
        mi21 = new MenuItem("Exportar");
        mi30 = new MenuItem("Versão");
        mi30.setOnAction(e -> {
            Alert at = new Alert(Alert.AlertType.INFORMATION);
            at.setTitle("MySQL-Fx Sobre");
            at.setResizable(false);
            at.setHeaderText("Versão 4.0");
            at.setContentText("Gerenciador para servidor MySQL.\nCriado por Nataniel.\nContado: natanieljava@gmail.com");
            at.showAndWait();
        });
        bar.getMenus().addAll(m1, m2, m3);
        m1.getItems().add(mi10);
        m1.getItems().add(mi11);
        m2.getItems().add(mi20);
        m2.getItems().add(mi21);
        m3.getItems().add(mi30);
    }

    public MenuItem getMi11() {
        return mi11;
    }

    public MenuBar getBar() {
        return bar;
    }

    public MenuItem getMi10() {
        return mi10;
    }

    public Menu getM2() {
        return m2;
    }

    public MenuItem getMi20() {
        return mi20;
    }

    public MenuItem getMi21() {
        return mi21;
    }

    public MenuItem getMi30() {
        return mi30;
    }

}
