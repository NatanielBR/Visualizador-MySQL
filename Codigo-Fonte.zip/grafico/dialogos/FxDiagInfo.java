package grafico.dialogos;

import dao.AutoComandoDAO;
import dao.ConexaoDAO;
import dao.InfoCenterDAO;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

/**
 *
 * @author oregan-nt
 */
public class FxDiagInfo{

    private Dialog diag;

    public Label getLb1() {
        return lb1;
    }

    public AutoComandoDAO getAcon() {
        return acon;
    }

    public InfoCenterDAO getCt() {
        return ct;
    }
    private Button bt1;
    private Thread tf = null;
    private boolean ativado = true;
    private Label lb1;
    private AutoComandoDAO acon = null;
    InfoCenterDAO ct = null;

    public FxDiagInfo(ConexaoDAO con) {
        acon = new AutoComandoDAO(con.getCon());
        acon.novocomando("show status");
        ct = new InfoCenterDAO(acon.obterResultado());
        lb1 = new Label("Ligado durante: ");
        VBox vb=new VBox();
        for (int i = 0; i < ct.getLinhaConteudo().size(); i++) {
            Object object = ct.getLinhaConteudo().get(i);
            String a = object.toString();
            if (a.contains("Uptime")) {
                lb1.setText("Ligado durante: "+ ct.getLinhaConteudo().get(i + 1));
                break;
            }

        }
        diag = new Dialog();
        diag.setTitle("Informações");
        diag.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        diag.getDialogPane().setContent(vb);
        vb.getChildren().add(lb1);
        bt1 = (Button) diag.getDialogPane().lookupButton(ButtonType.CLOSE);
        bt1.setOnAction(e -> {
            ativado=false;
        });
        diag.setOnCloseRequest(e->{
            ativado=false;
        });
    }

    public boolean isAtivado() {
        return ativado;
    }

    public Thread getTf() {
        return tf;
    }

    public Dialog getDiag() {
        return diag;
    }
    
}
