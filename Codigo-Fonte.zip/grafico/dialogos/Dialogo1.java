package grafico.dialogos;

import javafx.scene.Node;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import sql.DadosColuna;

/**
 *
 * @author nataniel
 */
public class Dialogo1 {

    private Label lb1 = null;
    private Label lb2 = null;
    private Label lb3 = null;
    private Label lb4 = null;
    private Label lb5 = null;

    private TextField fd1 = null;
    private TextField fd2 = null;
    private TextField fd3 = null;
    private TextField fd4 = null;
    private TextField fd5 = null;
    private Button btt = null;

    private Dialog dialogo = null;
    private DadosColuna dados = null;
    /**
     * Construdor que inicializa todos os controles que a classe possui e con-
     * figura pra formar uma janela de dialogo.
     */
    public Dialogo1() {
        dialogo = new Dialog<>();
        lb1 = new Label();
        lb2 = new Label();
        lb3 = new Label();
        lb4 = new Label();
        lb5 = new Label();
        fd1 = new TextField();
        fd2 = new TextField();
        fd3 = new TextField();
        fd4 = new TextField();
        fd5 = new TextField();
        GridPane pn = new GridPane();
        pn.setVisible(true);

        pn.add(lb1, 0, 0);
        pn.add(lb2, 1, 0);
        pn.add(lb3, 2, 0);
        pn.add(lb4, 3, 0);
        pn.add(lb5, 4, 0);
        pn.add(fd1, 0, 1);
        pn.add(fd2, 1, 1);
        pn.add(fd3, 2, 1);
        pn.add(fd4, 3, 1);
        pn.add(fd5, 4, 1);

        dialogo.getDialogPane().setContent(pn);

        dialogo.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialogo.getDialogPane().getButtonTypes().add(ButtonType.APPLY);
        Node bt = dialogo.getDialogPane().lookupButton(ButtonType.CLOSE);
        btt = (Button) dialogo.getDialogPane().lookupButton(ButtonType.APPLY);
        btt.setText("Atualizar");
        bt.managedProperty().bind(bt.visibleProperty());
        bt.setVisible(true);
    }
    private int qcoluna = 0;
    /**
     * Metodo privato que obtem os dados e configura a janela pra cada 
     * situação, por exemplo, caso tenha uma coluna: somente uma label vai
     * estar visivel e somente um TextField estará tambem, enquanto o restante
     * estara invisivel, alem da label irá ter como texto o valor correspondente
     * a coluna dos DadosColuna.
     * @param dc 
     */
    private void obter(DadosColuna dc) {
        if (!dc.getV1().equals("")) {
            qcoluna = 1;
            lb1.setText(dc.getV1());
            lb1.setVisible(true);
            lb2.setVisible(false);
            lb3.setVisible(false);
            lb4.setVisible(false);
            lb5.setVisible(false);
            fd1.setVisible(true);
            fd2.setVisible(false);
            fd3.setVisible(false);
            fd4.setVisible(false);
            fd5.setVisible(false);
        }

        if (!dc.getV2().equals("")) {
            qcoluna = 2;
            lb2.setText(dc.getV2());
            lb1.setVisible(true);
            lb2.setVisible(true);
            lb3.setVisible(false);
            lb4.setVisible(false);
            lb5.setVisible(false);
            fd1.setVisible(true);
            fd2.setVisible(true);
            fd3.setVisible(false);
            fd4.setVisible(false);
            fd5.setVisible(false);
        }

        if (!dc.getV3().equals("")) {
            qcoluna = 3;
            lb3.setText(dc.getV3());
            lb1.setVisible(true);
            lb2.setVisible(true);
            lb3.setVisible(true);
            lb4.setVisible(false);
            lb5.setVisible(false);
            fd1.setVisible(true);
            fd2.setVisible(true);
            fd3.setVisible(true);
            fd4.setVisible(false);
            fd5.setVisible(false);
        }

        if (!dc.getV4().equals("")) {
            qcoluna = 4;
            lb4.setText(dc.getV4());
            lb1.setVisible(true);
            lb2.setVisible(true);
            lb3.setVisible(true);
            lb4.setVisible(true);
            lb5.setVisible(false);
            fd1.setVisible(true);
            fd2.setVisible(true);
            fd3.setVisible(true);
            fd4.setVisible(true);
            fd5.setVisible(false);
        }

        if (!dc.getV5().equals("")) {
            qcoluna = 5;
            lb5.setText(dc.getV5());
            lb1.setVisible(true);
            lb2.setVisible(true);
            lb3.setVisible(true);
            lb4.setVisible(true);
            lb5.setVisible(true);
            lb1.setVisible(true);
            fd2.setVisible(true);
            fd3.setVisible(true);
            fd4.setVisible(true);
            fd5.setVisible(true);
        }
    }
    /**
     * Metodo que obtem os dados e forma uma janela de dialogo e exibe a mesma.
     * @param dc
     * Os dados da coluna selecionada.
     * @return 
     * Uma nova DadosColuna irá ser formada pra ser usada pra atualiazar a tabela
     * com o novo valor.
     */
    public DadosColuna mostrar(DadosColuna dc) {
        dados = null;
        this.obter(dc);
        btt.setOnAction(e -> {
            dados = new DadosColuna(qcoluna);
            this.criar(qcoluna);
        });

        dialogo.showAndWait();
        return dados;
    }
    /**
     * Metodo privato que irá criar a DadosColuna, de acordo com a quantidade e colunas.
     * @param qcoluna 
     * Parametro one informa a quantidade de colunas.
     */
    private void criar(int qcoluna) {
        if (qcoluna >= 1) {
            if (fd1.getText().equals("")) {
                dados.setV1(lb1.getText());
            }else{
                dados.setV1(fd1.getText());
            }
        }
        if (qcoluna >= 2) {
            if (fd1.getText().equals("")) {
                dados.setV1(lb1.getText());
            }else{
                dados.setV1(fd1.getText());
            }
            if (fd2.getText().equals("")) {
                dados.setV2(lb2.getText());
            }else{
                dados.setV2(fd2.getText());
            }
        }
        if (qcoluna >= 3) {
            if (fd1.getText().equals("")) {
                dados.setV1(lb1.getText());
            }else{
                dados.setV1(fd1.getText());
            }if (fd2.getText().equals("")) {
                dados.setV2(lb2.getText());
            }else{
                dados.setV2(fd2.getText());
            }if (fd3.getText().equals("")) {
                dados.setV3(lb3.getText());
            }else{
                dados.setV3(fd3.getText());
            }
        }
        if (qcoluna >= 4) {
            if (fd1.getText().equals("")) {
                dados.setV1(lb1.getText());
            }else{
                dados.setV1(fd1.getText());
            }if (fd2.getText().equals("")) {
                dados.setV2(lb2.getText());
            }else{
                dados.setV2(fd2.getText());
            }if (fd3.getText().equals("")) {
                dados.setV3(lb3.getText());
            }else{
                dados.setV3(fd3.getText());
            }if (fd4.getText().equals("")) {
                dados.setV4(lb4.getText());
            }else{
                dados.setV4(fd4.getText());
            }
        }
        if (qcoluna >= 5) {
            if (fd1.getText().equals("")) {
                dados.setV1(lb1.getText());
            }else{
                dados.setV1(fd1.getText());
            }if (fd2.getText().equals("")) {
                dados.setV2(lb2.getText());
            }else{
                dados.setV2(fd2.getText());
            }if (fd3.getText().equals("")) {
                dados.setV3(lb3.getText());
            }else{
                dados.setV3(fd3.getText());
            }if (fd4.getText().equals("")) {
                dados.setV4(lb4.getText());
            }else{
                dados.setV4(fd4.getText());
            }if (fd5.getText().equals("")) {
                dados.setV5(lb5.getText());
            }else{
                dados.setV5(fd5.getText());
            }
        }
    }
}
