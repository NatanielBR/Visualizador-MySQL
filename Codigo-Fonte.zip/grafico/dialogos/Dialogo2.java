package grafico.dialogos;

import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import sql.DadosColuna;
/**
 *
 * @author nataniel
 */
public class Dialogo2 {
    private Dialog dialogo=null;
    private Label lb1=null;
    private Label lb2=null;
    private Label lb3=null;
    private Label lb4=null;
    private Label lb5=null;
    
    private TextField fd1=null;
    private TextField fd2=null;
    private TextField fd3=null;
    private TextField fd4=null;
    private TextField fd5=null;
    private DadosColuna dados=null;
    private Button bt=null;
    /**
     * Construdor que irá inicializar todos os controles da janela e irá posicionar
     * todos.
     */
    public Dialogo2(){
        
        lb1=new Label();
        lb2=new Label();
        lb3=new Label();
        lb4=new Label();
        lb5=new Label();
        fd1=new TextField();
        fd2=new TextField();
        fd3=new TextField();
        fd4=new TextField();
        fd5=new TextField();
        GridPane pn=new GridPane();
        pn.setVisible(true);
        
        pn.add(lb1, 0, 0);
        pn.add(lb2, 1, 0);
        pn.add(lb3, 2, 0);
        pn.add(lb4, 3, 0);
        pn.add(lb5, 4, 0);
        pn.add(fd1, 0, 1);
        pn.add(fd2, 1, 1);
        pn.add(fd3, 2, 1);
        pn.add(fd4, 3, 1);
        pn.add(fd5, 4, 1);
        
        
        dialogo=new Dialog();
        dialogo.getDialogPane().setContent(pn);
        dialogo.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialogo.getDialogPane().getButtonTypes().add(ButtonType.APPLY);
        bt=(Button) dialogo.getDialogPane().lookupButton(ButtonType.APPLY);
        Button bt2=(Button) dialogo.getDialogPane().lookupButton(ButtonType.CLOSE);
        bt2.setOnAction(e->{
            dados=null;
        });
        bt.setText("Inserir");
    }
    private boolean feito=false;
    /**
     * Metodo que irá informar se a DadosColuna foi feita ou não.
     * @return 
     * Um valor boolean com a seguinte interpretação:
     * true- está feito.
     * false- não está feito.
     */
    public boolean isFeito() {
        return feito;
    }
    /**
     * Metodo que irá exibir a janela.
     * @param colunaNome
     * Uma array dos nomes das colunas, usado nas labels.
     * @return 
     * Uma nova dados coluna com novos valores.
     */
    public DadosColuna mostrar(String[] colunaNome){
        dados=new DadosColuna();
        feito=false;
        this.exibir(colunaNome);
        bt.setOnAction(e->{
            this.inserir(colunaNome);
            feito=true;
        });
        dialogo.showAndWait();
        return dados;
    }
    /**
     * Metodo privato que irá exibir as labels e as textfiel de acordo com a 
     * quantidade de colunas e a cada label irá ter o nome de cada coluna.
     * @param colunaNome 
     */
    private void exibir(String[] colunaNome){
        switch (colunaNome.length){
            case 1:
                lb1.setText(colunaNome[0]);
                lb1.setVisible(true);
                lb2.setVisible(false);
                lb3.setVisible(false);
                lb4.setVisible(false);
                lb5.setVisible(false);
                fd1.setVisible(true);
                fd2.setVisible(false);
                fd3.setVisible(false);
                fd4.setVisible(false);
                fd5.setVisible(false);
                break;
            case 2:
                lb1.setText(colunaNome[0]);
                lb2.setText(colunaNome[1]);
                lb1.setVisible(true);
                lb2.setVisible(true);
                lb3.setVisible(false);
                lb4.setVisible(false);
                lb5.setVisible(false);
                fd1.setVisible(true);
                fd2.setVisible(true);
                fd3.setVisible(false);
                fd4.setVisible(false);
                fd5.setVisible(false);
                break;
            case 3:
                lb1.setText(colunaNome[0]);
                lb2.setText(colunaNome[1]);
                lb3.setText(colunaNome[2]);
                lb1.setVisible(true);
                lb2.setVisible(true);
                lb3.setVisible(true);
                lb4.setVisible(false);
                lb5.setVisible(false);
                fd1.setVisible(true);
                fd2.setVisible(true);
                fd3.setVisible(true);
                fd4.setVisible(false);
                fd5.setVisible(false);
                break;
            case 4:
                lb1.setText(colunaNome[0]);
                lb2.setText(colunaNome[1]);
                lb3.setText(colunaNome[2]);
                lb4.setText(colunaNome[3]);
                lb1.setVisible(true);
                lb2.setVisible(true);
                lb3.setVisible(true);
                lb4.setVisible(true);
                lb5.setVisible(false);
                fd1.setVisible(true);
                fd2.setVisible(true);
                fd3.setVisible(true);
                fd4.setVisible(true);
                fd5.setVisible(false);
                break;
            case 5:
                lb1.setText(colunaNome[0]);
                lb2.setText(colunaNome[1]);
                lb3.setText(colunaNome[2]);
                lb4.setText(colunaNome[3]);
                lb5.setText(colunaNome[4]);
                lb1.setVisible(true);
                lb2.setVisible(true);
                lb3.setVisible(true);
                lb4.setVisible(true);
                lb5.setVisible(true);
                fd1.setVisible(true);
                fd2.setVisible(true);
                fd3.setVisible(true);
                fd4.setVisible(true);
                fd5.setVisible(true);
                break;
        }
    }
    /**
     * Metodo privato que irá formar uma nova dados coluna.
     * @param colunaNome 
     * Usado somente pra ter noção de quantas colunas a tabela possui.
     */
    private void inserir(String[] colunaNome){
        switch (colunaNome.length){
            case 0:
                dados.setV1(fd1.getText());
                break;
            case 1:
                dados.setV1(fd1.getText());
                dados.setV2(fd2.getText());
                break;
            case 2:
                dados.setV1(fd1.getText());
                dados.setV2(fd2.getText());
                dados.setV3(fd3.getText());
                break;
            case 3:
                dados.setV1(fd1.getText());
                dados.setV2(fd2.getText());
                dados.setV3(fd3.getText());
                dados.setV4(fd4.getText());
                break;
            case 4:
                dados.setV1(fd1.getText());
                dados.setV2(fd2.getText());
                dados.setV3(fd3.getText());
                dados.setV4(fd4.getText());
                dados.setV5(fd5.getText());
                break;
        }
    }
}
