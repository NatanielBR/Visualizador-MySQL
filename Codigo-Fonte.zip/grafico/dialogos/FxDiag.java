package grafico.dialogos;

import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Alert;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;

/**
 *
 * @author nataniel
 */
public class FxDiag {

    private Label lb = null;
    private Label lb1 = null;
    private final String apren = "Informe o valores para todas as colunas.";
    private TextField fd1 = null;
    private Button btt = null;
    private Button prox = null;

    private Dialog dialogo = null;

    /**
     * Construdor que inicializa todos os controles que a classe possui e con-
     * figura pra formar uma janela de dialogo.
     */
    public FxDiag() {
        dialogo = new Dialog<>();
        lb1 = new Label();
        lb = new Label();
        fd1 = new TextField();
        GridPane pn = new GridPane();
        pn.setVisible(true);
        dialogo.setOnCloseRequest(e -> {
            this.resultado = 1;
        });
        pn.add(lb, 0, 0);
        pn.add(lb1, 0, 1);
        pn.add(fd1, 1, 1);

        dialogo.getDialogPane().setContent(pn);
        dialogo.getDialogPane().getButtonTypes().add(ButtonType.NEXT);
        dialogo.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialogo.getDialogPane().getButtonTypes().add(ButtonType.APPLY);
        Button bt = (Button) dialogo.getDialogPane().lookupButton(ButtonType.CLOSE);
        prox = (Button) dialogo.getDialogPane().lookupButton(ButtonType.NEXT);
        btt = (Button) dialogo.getDialogPane().lookupButton(ButtonType.APPLY);
        btt.setOnAction(e -> {
            resultado = 2;
        });
        btt.setText("Aplicar");
        bt.managedProperty().bind(bt.visibleProperty());
        bt.setOnAction(e -> {
            resultado = 3;
        });
    }
    private int esc = 0;
    private boolean feito = false;
    private byte resultado = 0;

    public void reniciar() {
        esc = 0;
        feito = false;
        resultado = 0;
    }

    public byte getResultado() {
        return resultado;
    }

    private void obterAtualizar(String[] colunas, String[] valores) {
        if (esc <= colunas.length) {
            lb.setText(this.apren);
            lb1.setText("Coluna: " + colunas[esc] + "  Valor antigo: \"" + valores[esc] + "\"");
        }
    }

    public String mostrarAtualizar(String[] colunas, String[] valores) {
        this.obterAtualizar(colunas, valores);
        fd1.setText("");
        dialogo.setTitle("Assistente para atualizar a tabela.");
        List<String> info = new ArrayList();
        if (esc == colunas.length - 1) {
            prox.setVisible(false);
            btt.setVisible(true);
        } else {
            prox.setVisible(true);
            btt.setVisible(false);
        }
        prox.setOnAction(e -> {
            resultado = 0;
            if (!fd1.getText().equals("")) {
                info.add(fd1.getText());
                esc++;
            } else {
                info.add(valores[esc]);
                esc++;
            }
        });
        btt.setOnAction(e -> {
            resultado = 4;
            if (!fd1.getText().equals("")) {
                info.add(fd1.getText());
                esc++;
            } else {
                info.add(valores[esc]);
                esc++;
            }
        });
        dialogo.showAndWait();
        if (!info.isEmpty()) {
            return info.get(0);
        } else {
            return null;
        }
    }

    public String mostrarInserir(String[] colunas) {
        dialogo.setTitle("Assistende de criação de linhas.");
        fd1.setText("");
        this.obterInserir(colunas);
        List<String> info = new ArrayList();
        if (esc == colunas.length - 1) {
            prox.setVisible(false);
            btt.setVisible(true);
        } else {
            prox.setVisible(true);
            btt.setVisible(false);
        }
        prox.setOnAction(e -> {
            resultado = 0;
            if (!fd1.getText().equals("")) {
                info.add(fd1.getText());
                esc++;
            } else {
                Alert alerta = new Alert(Alert.AlertType.WARNING);
                alerta.setTitle("O espaço deve ser preenchido.");
                alerta.setHeaderText("Desculpa... mas o espaço deve ser preenchido.");
                alerta.setContentText("Por favor, preenche esse espaço!");
                alerta.showAndWait();
            }
        });
        btt.setOnAction(e -> {
            resultado = 4;
            if (!fd1.getText().equals("")) {
                info.add(fd1.getText());
                esc++;
            } else {
                Alert alerta = new Alert(Alert.AlertType.WARNING);
                alerta.setTitle("O espaço deve ser preenchido.");
                alerta.setHeaderText("Desculpa... mas o espaço deve ser preenchido.");
                alerta.setContentText("Por favor, preenche esse espaço!");
                alerta.showAndWait();
            }
        });
        dialogo.showAndWait();
        if (!info.isEmpty()) {
            return info.get(0);
        } else {
            return null;
        }
    }
    public void mostrarCriar(){
        dialogo.setTitle("Assistende de criação de linhas.");
        fd1.setText("");
        
        dialogo.showAndWait();
        
    }
    private void obterInserir(String[] colunas) {
        if (esc <= colunas.length) {
            lb.setText(this.apren);
            lb1.setText("Coluna: " + colunas[esc]);
        }
    }

    public boolean isFeito() {
        return feito;
    }
}
