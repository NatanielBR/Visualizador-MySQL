package grafico;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import sql.AutoComando;
import sql.Conexao;
import sql.InfoCenter;

/**
 * Cena onde será informado o banco de dados e a tabela.
 * @author nataniel
 */
public class CenaInfo2 {

    private Scene cena = null;
    private boolean pvez = true;
    private String bd = "";
    private String tabela = "";
    
    public Scene getCena() {
        return cena;
    }

    public CenaInfo2(Conexao con, CenaInfo info, Stage ps) {
        GridPane pn = new GridPane();
        cena = new Scene(pn, 400, 460);
        ComboBox<String> comb = new ComboBox();
        ComboBox<String> combt = new ComboBox();
        Button bt = new Button("Carregar");

        try {
            ResultSet rs = con.getCon().createStatement().executeQuery("show databases");
            while (rs.next()) {
                comb.getItems().add(rs.getString(1));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao obter os Banco de Dados.");
            System.exit(1);
        }
        comb.setOnAction((ActionEvent e) -> {
            if (!comb.getValue().equals("")) {
                try {
                    Statement st = con.getCon().createStatement();
                    bd = comb.getValue();
                    st.addBatch("use " + bd);
                    st.addBatch("show tables;");
                    if (pvez) {
                        pn.add(new Label("Selecione a Tabela"), 0, 1);
                    }
                    st.executeBatch();
                    ResultSet rss = st.getResultSet();
                    if (!pvez) {
                        combt.getItems().clear();
                        combt.autosize();
                    }
                    while (rss.next()) {
                        combt.getItems().add(rss.getString(1));
                    }
                    if (pvez) {
                        pn.add(combt, 1, 1);
                        pn.add(bt, 1, 3);
                        
                    }
                    pvez = false;
                } catch (SQLException ee) {
                    System.err.println("Erro ao obter as tabelas");
                }
            }
        });
        bt.setOnAction(e -> {
            tabela = combt.getValue();
            if (tabela!=null) {
                con.fazerConexao(new String[]{info.getIpC().concat("/" + bd), info.getUser(), info.getPass()});
                AutoComando ac = new AutoComando(con.getCon(), "select * from " + tabela);
                InfoCenter inf = new InfoCenter(ac.obterResultado());
                ps.setScene(new TabelaFx(inf, ac,tabela).getCena());
            }
        }
    );
    pn.add (
            

    new Label("Selecione o BD:"),0,0);
    pn.add (comb,
            

1, 0);
    }
    
}
