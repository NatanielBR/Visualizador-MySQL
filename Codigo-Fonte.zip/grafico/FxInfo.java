package grafico;

import java.sql.SQLException;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import dao.ConexaoDAO;
import io.EscreverLer;
import java.util.List;
import javafx.scene.layout.FlowPane;

/**
 * Cena inicial, onde será informado os dados para a conexao.
 *
 * @author nataniel
 */
public class FxInfo {

    private Scene info = null;
    private GridPane pn = null;
    private String ipC = "";
    private String user = "";
    private String pass = "";
    private TextField ip = null;
    private TextField porta = null;
    private TextField usuario = null;
    private PasswordField senha = null;

    public String getIpC() {
        return ipC;
    }

    public FxInfo(Stage ps, ConexaoDAO con) {
        pn = new GridPane();
        info = new Scene(pn, 250, 360);
        ip = new TextField();
        porta = new TextField();
        usuario = new TextField();
        senha = new PasswordField();
        FlowPane pne=new FlowPane();
        Button bt = new Button("Conectar");
        Button sal=new Button("Salvar");
        Button carr=new Button("Carregar");

        pn.add(new HBox(32.0, new Label("Ip:"), ip), 0, 0);
        pn.add(new HBox(14.0, new Label("Porta:"), porta), 0, 1);
        pn.add(new HBox(3.0, new Label("Usuario:"), usuario), 0, 2);
        pn.add(new HBox(11.0, new Label("Senha:"), senha), 0, 3);
        pn.add(new HBox(19, bt), 0, 4);
        pn.add(pne,0,5);
        
        pne.getChildren().addAll(sal,carr);
        sal.setOnAction(e->{
            this.salvar();
        });
        
        carr.setOnAction(e->{
            this.carregar();
        });
        
        bt.setOnAction(e -> {
            ipC = ip.getText();
            Alert ale = new Alert(Alert.AlertType.INFORMATION);
            ale.setHeaderText("Estamos tentando conecatar.");
            ale.setTitle("Conectando...");
            ale.setContentText("Aguarde um pouco... isso pode demorar um pouco.");
            ale.show();
            try {
                Integer.parseInt(porta.getText());

                if (!ipC.contains("jdbc:mysql://")) {
                    StringBuilder c = new StringBuilder();
                    c.append("jdbc:mysql://");
                    c.append(ip.getText());
                    c.append(":");
                    c.append(porta.getText());
                    ipC = c.toString();
                }
                con.fazerConexaoT(new String[]{ipC, usuario.getText(), senha.getText()});
                this.user = usuario.getText();
                this.pass = senha.getText();
                ps.setScene(new FxInfo2(con, this, ps).getCena());
                ale.close();
            } catch (NumberFormatException err) {
                ale.setHeaderText("Ops... Achei um erro!");
                ale.setContentText("Você colocou algo que não seja numero na porta!");
            } catch (SQLException er2) {
                ale.setAlertType(Alert.AlertType.ERROR);
                ale.setHeaderText("Isso não é nosso... Eu juro!");
                ale.setContentText("Não foi possivel conectar no Banco de Dados!");
                er2.printStackTrace();
            }
        });
    }

    public String getUser() {
        return user;
    }

    public String getPass() {
        return pass;
    }

    public Scene getInfo() {
        return info;
    }

    public void salvar() {
        EscreverLer.ativarEscrita("info");
        StringBuilder bd = new StringBuilder();
        bd.append("ser=");
        bd.append(ip.getText());
        bd.append("\n");
        bd.append("por=");
        bd.append(porta.getText());
        bd.append("\n");
        bd.append("usu=");
        bd.append(usuario.getText());
        bd.append("\n");
        bd.append("sen=");
        bd.append(senha.getText());
        EscreverLer.escrever(bd.toString());
    }

    public void carregar() {
        List a = EscreverLer.ler("info");
        if (a!=null) {
            int b = 0;
            for (Object ob : a) {
                String o = ob.toString();
                o = o.substring(4);
                switch (b) {
                    case 0:
                        ip.setText(o);
                        break;
                    case 1:
                        porta.setText(o);
                        break;
                    case 2:
                        usuario.setText(o);
                        break;
                    case 3:
                        senha.setText(o);
                        break;
                }
                b++;
            }
        }
    }
}
