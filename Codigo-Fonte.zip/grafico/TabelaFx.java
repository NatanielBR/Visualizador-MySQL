package grafico;

import grafico.dialogos.Dialogo1;
import grafico.dialogos.Dialogo2;
import java.util.Arrays;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import sql.AutoComando;
import sql.DadosColuna;
import sql.InfoCenter;

/**
 *
 * @author nataniel
 */
public class TabelaFx {

    private TableView<DadosColuna> vt = null;
    private TableColumn<DadosColuna, Object>[] colunas;
    private Scene cena = null;
    private int ponteiro = 0;
    private int linha = 0;
    private Button bt = null;
    private DadosColuna dadosSel = null;
    private Button bt2 = null;
    private Button bt3 = null;
    private InfoCenter ct = null;
    List<DadosColuna> conteudo = null;

    /**
     * Construdor que "constroi" a cena e coloca em devido canto cada controle.
     * O constudor tambem contem as ações da TableView e dos Botões.
     *
     * @param ct Nescessario informar a classe InfoCenter, na qual irá ser util
     * pra prati- camente tudo.
     * @see InfoCenter
     * @param com AutoComano será nescessario pra, praticamente, tudo tambem,
     * porém sua caracteristica maior será pra atualizar (Olhe o codigo da
     * classe).
     * @see AutoComando
     * @param tabela Será nescessario, principalmente, para os comandos de
     * atualização e outros como update, insert e delete.
     */
    public TabelaFx(InfoCenter ct, AutoComando com, String tabela) {
        vt = new TableView();
        Dialogo1 diag = new Dialogo1();
        Dialogo2 diag2 = new Dialogo2();
        bt2 = new Button("Inserir");
        bt3 = new Button("Remover");
        bt3.setVisible(false);
        this.ct = ct;
        colunas = ct.getTabela();
        conteudo=FXCollections.observableArrayList();
        vt.getColumns().addAll(Arrays.asList(colunas));

        for (int i = 0; i != colunas.length; i++) {
            colunas[i].setCellValueFactory(new PropertyValueFactory("v" + String.valueOf(i + 1)));
        }
        
        for (int i = 0; i != ct.getLinhaQuant(); i++) {
            conteudo.add(ct.getDadosColuna());
            DadosColuna a = (DadosColuna) conteudo.get(i);

            while (true) {
                if (ponteiro == colunas.length) {
                    ponteiro = 0;
                    this.linha += ct.getColunaQuant();
                    break;
                }
                switch (ct.getColunaQuant()) {
                    case 1:
                        a.setV1(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        break;
                    case 2:
                        a.setV1(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV2(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        break;
                    case 3:
                        a.setV1(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV2(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV3(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        break;
                    case 4:
                        a.setV1(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV2(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV3(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV4(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        break;
                    case 5:
                        a.setV1(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV2(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV3(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV4(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV5(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        break;
                }
            }
        }

        vt.setItems(FXCollections.observableList(conteudo));
        
        vt.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2) {
                DadosColuna antigo = vt.getSelectionModel().getSelectedItem();
                DadosColuna dados = diag.mostrar(antigo);
                if (dados != null) {
                    StringBuilder bd = new StringBuilder();
                    bd.append("update ");
                    bd.append(tabela);
                    bd.append(" set ");
                    for (int i = 0; i != this.ct.getColunaQuant(); i++) {
                        bd.append(ct.getColunaNome()[i]);
                        bd.append("=");
                        bd.append("'");
                        bd.append(dados.getValores()[i]);
                        bd.append("'");
                        if (i + 1 != ct.getColunaQuant()) {
                            bd.append(",");
                        }
                    }
                    bd.append(" where ");
                    for (int i = 0; i != this.ct.getColunaQuant(); i++) {
                        bd.append(ct.getColunaNome()[i]);
                        bd.append("=");
                        bd.append("'");
                        bd.append(antigo.getValores()[i]);
                        bd.append("'");
                        if (i + 1 != ct.getColunaQuant()) {
                            bd.append(" and ");
                        }
                    }
                    com.novocomando(bd.toString());
                    com.novocomando("select * from " + tabela);
                    this.ct.atualizar(com.obterResultado());
                    if (!ct.isTabelaLimpa()) {
                        this.atualizar();
                    } else {
                        this.tabelaLimpar();
                    }
                }
            } else if (e.getClickCount() == 1) {
                if (bt3.isVisible()) {
                    vt.getSelectionModel().clearSelection();
                    bt3.setVisible(false);
                } else {
                    dadosSel = vt.getSelectionModel().getSelectedItem();
                    bt3.setVisible(true);
                }
            }
        });
        bt = new Button("Atualizar");
        bt3.setOnAction(e -> {
            DadosColuna dados = vt.getSelectionModel().getSelectedItem();
            StringBuilder bd = new StringBuilder();
            bd.append("delete from ");
            bd.append(tabela);
            bd.append(" where ");
            for (int i = 0; i != this.ct.getColunaQuant(); i++) {
                bd.append(ct.getColunaNome()[i]);
                bd.append("=");
                bd.append("'");
                bd.append(dados.getValores()[i]);
                bd.append("'");
                if (i + 1 != ct.getColunaQuant()) {
                    bd.append(" and ");
                }
            }
            System.out.println(bd.toString());
            com.novocomando(bd.toString());
            com.novocomando("select * from " + tabela);
            this.ct.atualizar(com.obterResultado());
            if (!ct.isTabelaLimpa()) {
                this.atualizar();
            } else {
                this.tabelaLimpar();
            }
            bt3.setVisible(false);
        });
        bt.setOnAction(e -> {
            bt.setVisible(false);
            com.autoComando();
            this.ct.atualizar(com.obterResultado());
            if (!ct.isTabelaLimpa()) {
                this.atualizar();
            } else {
                this.tabelaLimpar();
            }
            bt.setVisible(true);
        });
        bt2.setOnAction(e -> {
            DadosColuna dados = diag2.mostrar(ct.getColunaNome());
            if (diag2.isFeito()) {

                StringBuilder bd = new StringBuilder();
                bd.append("insert into ");
                bd.append(tabela);
                bd.append(" (");
                for (int i = 0; i != this.ct.getColunaQuant(); i++) {
                    bd.append(ct.getColunaNome()[i]);
                    if (i + 1 != ct.getColunaQuant()) {
                        bd.append(",");
                    }
                }
                bd.append(")");
                bd.append(" values (");
                for (int i = 0; i != this.ct.getColunaQuant(); i++) {
                    bd.append("'");
                    bd.append(dados.getValores()[i]);
                    bd.append("'");
                    if (i + 1 != ct.getColunaQuant()) {
                        bd.append(",");
                    }
                }
                bd.append(")");
                com.novocomando(bd.toString());
                com.novocomando("select * from " + tabela);
                this.ct.atualizar(com.obterResultado());
                if (!ct.isTabelaLimpa()) {
                    this.atualizar();
                } else {
                    this.tabelaLimpar();
                }
            }
        }
        );
        vt.setItems(FXCollections.observableList(conteudo));
        VBox pn = new VBox();
        FlowPane pn2 = new FlowPane(5, 5);
        cena = new Scene(pn, 400, 460);

        pn.getChildren().addAll(vt, pn2);
        pn2.getChildren().addAll(bt, bt2, bt3);
    }

    /**
     * Ela evita que se escreva a mesma coisa.
     */
    public void tabelaLimpar() {
        vt.getColumns().clear();
        ct.limparColuna();
    }
    
    /**
     * Metodo que Atualiza a tabela e serve tambem pra criar a mesma
     */
    public void atualizar() {
        linha = 0;
        ponteiro = 0;
        colunas = ct.getTabela();
        ct.limparColuna();
        vt.getColumns().clear();
        conteudo = null;
        conteudo = FXCollections.observableArrayList();
        vt.getColumns().addAll(Arrays.asList(colunas));
        for (int i = 0; i != colunas.length; i++) {
            colunas[i].setCellValueFactory(new PropertyValueFactory("v" + String.valueOf(i + 1)));
        }

        for (int i = 0; i != ct.getLinhaQuant()-1; i++) {
            conteudo.add(ct.getDadosColuna());
            DadosColuna a = (DadosColuna) conteudo.get(i);

            while (true) {
                if (ponteiro == colunas.length) {
                    ponteiro = 0;
                    this.linha += ct.getColunaQuant();
                    break;
                }
                switch (ct.getColunaQuant()) {
                    case 1:
                        a.setV1(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        break;
                    case 2:
                        a.setV1(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV2(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        break;
                    case 3:
                        a.setV1(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV2(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV3(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        break;
                    case 4:
                        a.setV1(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV2(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV3(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV4(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        break;
                    case 5:
                        a.setV1(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV2(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV3(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV4(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        a.setV5(String.valueOf(ct.getLinhaConteudo().get(ponteiro + linha)));
                        ponteiro++;
                        break;
                }
            }
        }

        vt.setItems(FXCollections.observableList(conteudo));

    }

    public Scene getCena() {
        return cena;
    }

}
