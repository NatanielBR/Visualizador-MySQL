package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import java.sql.Statement;

/**
 *  Classe que faz diversos procedimentos automaticos pra 
 * encurtar as linhas de codigo.
 * @author nataniel
 */
public class AutoComandoDAO {
    private Connection conexao=null;
    private String ulComando="";
    private Statement st=null;
    private ResultSet rs=null;
    /**
     * Metodo que irá retornar o resultado do comando.
     * @return 
     * Uma ResultSet contendo o resultado do comando.
     * Será null se o comando for insert,update ou delete.
     */
    public ResultSet obterResultado(){
        return rs;
    }
    /**
     * Metodo que irá executar o comando e ira retornar o resultado.
     * @param comando
     * Comando em String.
     * @return 
     * Resultado em ResultSet.
     * Será null se o comando for insert,update ou delete.
     */
    public ResultSet novocomando(String comando){
        try {
            
            ulComando=comando;
            st=null;
            st=conexao.createStatement();
            if(comando.contains("insert")||comando.contains("update")||comando.contains("delete")){
                st.execute(comando);
                st=null;
            }else{
                rs=st.executeQuery(comando);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao realizar o comando.");
            System.err.println("\tcomando: \""+comando+"\" .");
            System.err.println("\t\tClasse: 'AutoComando' .");
            System.err.println("\t\t\tMetodo: 'novoComando' .");
            e.printStackTrace();
        }
        return rs;
    }
    /**
     * Metodo que executa o utlimo comando.
     * É nescessario usar o metodo obterResultado pra realmente obter o resultado.
     */
    public void autoComando(){
        this.novocomando(ulComando);
    }
    /**
     * Construdor que irá nescessita uma conexao e um comando inicial.
     * @param con
     * Uma Connection pra executar os comandos.
     * @param comando 
     * O comando em si.
     */
    private boolean feito=false;
    public AutoComandoDAO(Connection con){
        conexao=con;
    }
    public AutoComandoDAO(Connection con, String comando) {
        conexao=con;
        ulComando=comando;
        try {
            feito=false;
            st=conexao.createStatement();
            if(comando.contains("insert")||comando.contains("update")){
                st.execute(comando);
                st=null;
            }else{
                rs=st.executeQuery(comando);
            }
            feito=true;
        } catch (SQLException e) {
            System.err.println("Erro ao realizar o procedimento automatico.");
            System.err.println("\tClasse: AutoComando");
            if(e.getMessage().contains("disable")){
                Alert alerta=new Alert(AlertType.ERROR);
                alerta.setTitle("MySQL-Fx Erro");
                alerta.setHeaderText("Desativado!");
                alerta.setContentText("Essa tabela foi desativado, mas não por nois!");
                alerta.showAndWait();
            }else{
                System.exit(1);
            }
        }
    }

    public boolean isFeito() {
        return feito;
    }
    
}
