package dao;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author nataniel
 */
public class ConexaoDAO {

    private Connection con = null;

    public Connection getCon() {
        return con;
    }

    public Connection fazerConexao(String[] info){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(info[0], info[1], info[2]);
        } catch (ClassNotFoundException | SQLException e) {
            System.exit(1);
        }
        
        return con;
    }
    public Connection fazerConexaoT(String[] info) throws SQLException{
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.exit(1);
        }
        con = DriverManager.getConnection(info[0], info[1], info[2]);
        
        return con;
    }

    public ConexaoDAO() {

    }
    public void encerrar(){
        if(con!=null){
            try {
                con.close();
            } catch (SQLException ex) {
            }
        }else{
            con=null;
        }
    }
    public ConexaoDAO(String[] info) {
        try {
            con = DriverManager.getConnection(info[0], info[1], info[2]);
        } catch (SQLException ex) {
            System.err.println("Erro ao fazer a conexao.\n classe: Conexao");
            System.exit(1);
        }
    }

}
