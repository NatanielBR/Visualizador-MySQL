/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mysql.fx;

import grafico.CenaInfo;
import javafx.application.Application;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Menu;
import javafx.stage.Stage;
import sql.Conexao;

/**
 *
 * @author nataniel
 */
public class Main extends Application{
    public static void main(String[] args) {
        launch(args);
    }
    private Conexao con=null;

    public void start(Stage ps){
        
        con=new Conexao();
        CenaInfo info=new CenaInfo(ps,con);
        ps.setScene(info.getInfo());
        ps.setTitle("Gerenciador MySQL");
        
        ps.show();
    }
    
}
